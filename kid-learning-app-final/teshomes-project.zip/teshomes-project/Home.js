import * as React from 'react';
import {ScrollView, Text, View, StyleSheet ,Button,TouchableOpacity,ImageBackground} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import Alphabets from "./Alphabets";
import Numbers from './Numbers';
import Words from './Words';
import App from './App';

const image = { uri: "https://is2-ssl.mzstatic.com/image/thumb/Purple126/v4/6a/e6/dc/6ae6dcbf-b4f3-477d-e18c-4dca49c4b9d2/AppIconOmni-1x_U007emarketing-0-7-0-85-220.png/512x512bb.jpg" };
export default function Home({navigation}){
return(
  <ImageBackground 
  source={image}    style={{width:'100%',height:'100%'}}>
<View   style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
<Text style={{padding:35,paddingLeft:50, color:'red',fontSize:30,fontWeight:'bold'}}>Home Screen</Text>
<Button 
title='Go to Alphabet'
onPress={()=>navigation.navigate('Alphabet')}
/>
<Text style={{padding:10}}></Text>
<Button 
style={{top:130,bottm:30}}
title="Go to  Words"
onPress={()=>navigation.navigate('Words')} />
<Text style={{padding:10}}></Text>
<Button 
style={{top:130,bottm:30}}
title="Go to  Number"
onPress={()=>navigation.navigate('Numbers')} />
</View>
</ImageBackground>

);
}





