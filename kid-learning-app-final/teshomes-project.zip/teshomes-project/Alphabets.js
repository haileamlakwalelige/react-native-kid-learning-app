import * as React from 'react';
import { Text, View, StyleSheet,TouchableOpacity,ImageBackground } from 'react-native';
import Words from './Words';

const kid=require('./assets/giraffe.jpg');
export default function Alphabets() {
  return (
    <View  style={styles.container} >
    <ImageBackground source={kid} >
  <View style={{flexDirection:'row'}}>
  <TouchableOpacity  style={styles.button}>
  <Text style={styles.texty}>A</Text>
  </TouchableOpacity>
  <TouchableOpacity    style={styles.button}>
  <Text style={styles.texty}>B</Text>
  </TouchableOpacity>
  <TouchableOpacity    style={styles.button}>
  <Text style={styles.texty}>C</Text>
  </TouchableOpacity>
    </View>
    <View style={{flexDirection:'row'}}>
  <TouchableOpacity  style={styles.button}>
  <Text style={styles.texty}>D</Text>
  </TouchableOpacity >
  <TouchableOpacity   style={styles.button}>
  <Text style={styles.texty}>E</Text>
  </TouchableOpacity>
  <TouchableOpacity   style={styles.button}>
  <Text style={styles.texty}>F</Text>
  </TouchableOpacity>
    </View>
    <View style={{flexDirection:'row'}}>
  <TouchableOpacity  style={styles.button}>
  <Text style={styles.texty}>G</Text>
  </TouchableOpacity>
  <TouchableOpacity    style={styles.button}>
  <Text style={styles.texty}>H</Text>
  </TouchableOpacity>
  <TouchableOpacity    style={styles.button}>
  <Text style={styles.texty}>I</Text>
  </TouchableOpacity>
    </View>
    <View style={{flexDirection:'row'}}>
  <TouchableOpacity  style={styles.button}>
  <Text style={styles.texty}>J</Text>
  </TouchableOpacity >
  <TouchableOpacity   style={styles.button}>
  <Text style={styles.texty}>K</Text>
  </TouchableOpacity>
  <TouchableOpacity   style={styles.button}>
  <Text style={styles.texty}>L</Text>
  </TouchableOpacity>
    </View>
    <View style={{flexDirection:'row'}}>
  <TouchableOpacity  style={styles.button}>
  <Text style={styles.texty}>M</Text>
  </TouchableOpacity>
  <TouchableOpacity    style={styles.button}>
  <Text style={styles.texty}>N</Text>
  </TouchableOpacity>
  <TouchableOpacity    style={styles.button}>
  <Text style={styles.texty}>O</Text>
  </TouchableOpacity>
    </View>
    <View style={{flexDirection:'row'}}>
  <TouchableOpacity  style={styles.button}>
  <Text style={styles.texty}>P</Text>
  </TouchableOpacity >
  <TouchableOpacity   style={styles.button}>
  <Text style={styles.texty}>Q</Text>
  </TouchableOpacity>
  <TouchableOpacity   style={styles.button}>
  <Text style={styles.texty}>R</Text>
  </TouchableOpacity>
    </View>
    <View style={{flexDirection:'row'}}>
  <TouchableOpacity  style={styles.button}>
  <Text style={styles.texty}>S</Text>
  </TouchableOpacity>
  <TouchableOpacity    style={styles.button}>
  <Text style={styles.texty}>T</Text>
  </TouchableOpacity>
  <TouchableOpacity    style={styles.button}>
  <Text style={styles.texty}>U</Text>
  </TouchableOpacity>
    </View>
    <View style={{flexDirection:'row'}}>
  <TouchableOpacity  style={styles.button}>
  <Text style={styles.texty}>V</Text>
  </TouchableOpacity >
  <TouchableOpacity   style={styles.button}>
  <Text style={styles.texty}>W</Text>
  </TouchableOpacity>
  <TouchableOpacity   style={styles.button}>
  <Text style={styles.texty}>X</Text>
  </TouchableOpacity>
    </View>
    <View style={{flexDirection:'row',paddingLeft:50}}>
  <TouchableOpacity  style={styles.button}>
  <Text style={styles.texty}>Y</Text>
  </TouchableOpacity >
  <TouchableOpacity   style={styles.button}>
  <Text style={styles.texty}>Z</Text>
  </TouchableOpacity>
  
    </View>

     </ImageBackground>
    </View>
  );
}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 10,
  
  },
  texty: {
    color: "#0000ff",
    fontWeight: "900",
    fontSize: 20,
 },
 button: {
    alignItems: "center",
    backgroundColor: "#FF00FF",
    padding:10,
    left:0,
    right:10,
    width:100,
    top:10,
    margin:3,
    
     elevation: 60,
  borderRadius: 80,
  },
  
});
