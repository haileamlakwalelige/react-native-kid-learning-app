import React from 'react';
import {View,ScrollView,Text,ImageBackground,StyleSheet,Button,TouchableOpacity} from 'react-native';

const image = { uri: "https://is2-ssl.mzstatic.com/image/thumb/Purple126/v4/6a/e6/dc/6ae6dcbf-b4f3-477d-e18c-4dca49c4b9d2/AppIconOmni-1x_U007emarketing-0-7-0-85-220.png/512x512bb.jpg" };

const Handle=()=>{
  alert("YOU CLICK THE BUTTON");
}

const Numbers=()=>{
return(
  
 <ScrollView style={styles.container}>
    <ImageBackground source={image} resizeMode="cover" style={{height:1500}}>
    <Text style={styles.text}>ENGLISH ALPHABET</Text>
    <View style={styles.view}>
     <TouchableOpacity
        style={styles.button}
        
      >
        <Text>A</Text>
      </TouchableOpacity>
      <Text style={{marginBottom:20}}></Text>
        <TouchableOpacity
        style={styles.button}
        
      >
        <Text>B</Text>
      </TouchableOpacity>
      <Text style={{marginBottom:20}}></Text>
        <TouchableOpacity
        style={styles.button}
        
      >
        <Text>C</Text>
      </TouchableOpacity>
      <Text style={{marginBottom:20}}></Text>
      <TouchableOpacity
        style={styles.button}
        
      >
        <Text>D</Text>
      </TouchableOpacity>
      <Text style={{marginBottom:20}}></Text>
      <TouchableOpacity
        style={styles.button}
        
      >
        <Text>E</Text>
      </TouchableOpacity>
      <Text style={{marginBottom:20}}></Text>
      <TouchableOpacity
        style={styles.button}
        
      >
        <Text>F</Text>
      </TouchableOpacity>
      <Text style={{marginBottom:20}}></Text>
     <TouchableOpacity
        style={styles.button}
        
      >
        <Text>G</Text>
      </TouchableOpacity>
      <Text style={{marginBottom:20}}></Text>
     <TouchableOpacity
        style={styles.button}
        
      >
        <Text>H</Text>
      </TouchableOpacity>
      <Text style={{marginBottom:20}}></Text>
     <TouchableOpacity
        style={styles.button}
        
      >
        <Text>I</Text>
      </TouchableOpacity>
      <Text style={{marginBottom:20}}></Text>
      <TouchableOpacity
        style={styles.button}
        
      >
        <Text>J</Text>
      </TouchableOpacity>
      <Text style={{marginBottom:20}}></Text>
     
      <Text style={{marginBottom:20}}></Text>
      <TouchableOpacity
        style={styles.button}
        
      >
        <Text>K</Text>
      </TouchableOpacity>
      <Text style={{marginBottom:20}}></Text>
      <TouchableOpacity
        style={styles.button}
        
      >
        <Text>L</Text>
      </TouchableOpacity>
      <Text style={{marginBottom:20}}></Text>
     <TouchableOpacity
        style={styles.button}
        
      >
        <Text>M</Text>
      </TouchableOpacity>
      <Text style={{marginBottom:20}}></Text>
      <TouchableOpacity
        style={styles.button}
        
      >
        <Text>N</Text>
      </TouchableOpacity>
      <Text style={{marginBottom:20}}></Text>
      <TouchableOpacity
        style={styles.button}
        
      >
        <Text>O</Text>
      </TouchableOpacity>
      <Text style={{marginBottom:20}}></Text>
      <TouchableOpacity
        style={styles.button}
        
      >
        <Text>P</Text>
      </TouchableOpacity>
      <Text style={{marginBottom:20}}></Text>
     <TouchableOpacity
        style={styles.button}
        
      >
        <Text>Q</Text>
      </TouchableOpacity>
      <Text style={{marginBottom:20}}></Text>
      <TouchableOpacity
        style={styles.button}
        
      >
        <Text>R</Text>
      </TouchableOpacity>
      <Text style={{marginBottom:20}}></Text>
      <TouchableOpacity
        style={styles.button}
        
      >
        <Text>S</Text>
      </TouchableOpacity>
      <Text style={{marginBottom:20}}></Text>
      <TouchableOpacity
        style={styles.button}
        
      >
        <Text>T</Text>
      </TouchableOpacity>
      <Text style={{marginBottom:20}}></Text>
      <TouchableOpacity
        style={styles.button}
        
      >
        <Text>U</Text>
      </TouchableOpacity>
      <Text style={{marginBottom:20}}></Text>
     <TouchableOpacity
        style={styles.button}
        
      >
        <Text>V</Text>
      </TouchableOpacity>
      <Text style={{marginBottom:20}}></Text>
      <TouchableOpacity
        style={styles.button}
        
      >
        <Text>W</Text>
      </TouchableOpacity>
      <Text style={{marginBottom:20}}></Text>
      <TouchableOpacity
        style={styles.button}
        
      >
        <Text>X</Text>
      </TouchableOpacity>
      <Text style={{marginBottom:20}}></Text>
      <TouchableOpacity
        style={styles.button}
        
      >
        <Text>Y</Text>
      </TouchableOpacity>
      <Text style={{marginBottom:20}}></Text>
      <TouchableOpacity
        style={styles.button}
        
      >
        <Text>Z</Text>
      </TouchableOpacity>
       </View>
      </ImageBackground>
     
  </ScrollView>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
 
  text: {
     color: "white",
    fontSize: 30,
    lineHeight: 84,
    fontWeight: "bold",
    textAlign: "center",
    backgroundColor: "#000000c0",
    merginBottom:20,
  },
  view:{
    
    flexDirection:'row',
    justifyContent:'space-around',

  },
    button: {
    alignItems: "center",
    backgroundColor: "#DDDDDD",
    padding: 10,
    left:50,
    width:100,
    top:10,
  },
});
export default Numbers;